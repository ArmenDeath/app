Free for personal and commercial use

Buy the full version of Arodora Pro typeface:

https://www.myfonts.com/fonts/serdar-ozturk/arodora-pro/

Subscribe and follow:

https://www.behance.net/srdroztrk

http://instagram.com/arodoragency

http://www.arodora.com/